package Contact;

import java.util.ArrayList;

public class ContactService {
    private final ArrayList<Contact> contactList = new ArrayList<>();

    public void displayContactList() {
        for (Contact contact : contactList) {
            System.out.println("\t Contact ID: " + contact.getContactID());
            System.out.println("\t First Name: " + contact.getFirstName());
            System.out.println("\t Last Name: " + contact.getLastName());
            System.out.println("\t Phone Number: " + contact.getPhone());
            System.out.println("\t Address: " + contact.getAddress() + "\n");
        }
    }

    public void addContact(String contactID, String firstName, String lastName, String phone, String address) {
        Contact contact = new Contact(contactID, firstName, lastName, phone, address);
        contactList.add(contact);
    }

    public Contact getContact(String contactID) {
        for (Contact contact : contactList) {
            if (contact.getContactID().equals(contactID)) {
                return contact;
            }
        }
        // Return null or handle this case based on your requirements
        return null;
    }

    public void deleteContact(String contactID) {
        contactList.removeIf(contact -> contact.getContactID().equals(contactID));
    }

    public void updateFirstName(String updatedString, String contactID) {
        Contact contact = getContact(contactID);
        if (contact != null) {
            contact.setFirstName(updatedString);
        }
    }

    public void updateLastName(String updatedString, String contactID) {
        Contact contact = getContact(contactID);
        if (contact != null) {
            contact.setLastName(updatedString);
        }
    }

    public void updatePhone(String updatedString, String contactID) {
        Contact contact = getContact(contactID);
        if (contact != null) {
            contact.setPhone(updatedString);
        }
    }

    public void updateAddress(String updatedString, String contactID) {
        Contact contact = getContact(contactID);
        if (contact != null) {
            contact.setAddress(updatedString);
        }
    }
}

package Test;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import Contact.Contact;

public class ContactTest {

    @Test
    void testContactConstructor() {
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");

        assertNotNull(contact.getContactID(), "Contact ID should not be null");
        assertEquals("John", contact.getFirstName(), "First name should be John");
        assertEquals("Doe", contact.getLastName(), "Last name should be Doe");
        assertEquals("1234567890", contact.getPhone(), "Phone number should be 1234567890");
        assertEquals("123 Main St", contact.getAddress(), "Address should be 123 Main St");
    }

    @Test
    void testContactConstructorWithInvalidValues() {
        Exception exception;

        // Contact ID too long
        exception = assertThrows(IllegalArgumentException.class, () -> new Contact("12345678901", "John", "Doe", "1234567890", "123 Main St"));
        assertEquals("Invalid contact ID", exception.getMessage());

        // First name too long
        exception = assertThrows(IllegalArgumentException.class, () -> new Contact("1", "ThisNameIsWayTooLong", "Doe", "1234567890", "123 Main St"));
        assertEquals("Invalid first name", exception.getMessage());

        // Last name too long
        exception = assertThrows(IllegalArgumentException.class, () -> new Contact("1", "John", "ThisNameIsWayTooLong", "1234567890", "123 Main St"));
        assertEquals("Invalid last name", exception.getMessage());

        // Phone number invalid
        exception = assertThrows(IllegalArgumentException.class, () -> new Contact("1", "John", "Doe", "12345", "123 Main St"));
        assertEquals("Invalid phone number", exception.getMessage());

        // Address too long
        exception = assertThrows(IllegalArgumentException.class, () -> new Contact("1", "John", "Doe", "1234567890", "ThisAddressIsWayTooLongAndShouldFailValidation"));
        assertEquals("Invalid address", exception.getMessage());
    }

    @Test
    void testSetters() {
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");

        contact.setFirstName("Jane");
        assertEquals("Jane", contact.getFirstName(), "First name should be updated to Jane");

        contact.setLastName("Smith");
        assertEquals("Smith", contact.getLastName(), "Last name should be updated to Smith");

        contact.setPhone("0987654321");
        assertEquals("0987654321", contact.getPhone(), "Phone number should be updated to 0987654321");

        contact.setAddress("456 Elm St");
        assertEquals("456 Elm St", contact.getAddress(), "Address should be updated to 456 Elm St");
    }
}

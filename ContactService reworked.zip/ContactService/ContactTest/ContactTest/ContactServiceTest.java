package Test;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import static org.junit.jupiter.api.Assertions.*;
import Contact.Contact;
import Contact.ContactService;

@TestMethodOrder(OrderAnnotation.class)
public class ContactServiceTest {

    @Test
    @DisplayName("Test to Update First Name.")
    void testUpdateFirstName() {
        ContactService service = new ContactService();
        service.addContact("1", "Dr.", "Cross", "5555551111", "123 Lollypop Lane");
        String contactID = service.getContact("1").getContactID();
        service.updateFirstName("Sven", contactID);
        assertEquals("Sven", service.getContact(contactID).getFirstName(), "First name was not updated.");
    }

    @Test
    @DisplayName("Test to Update Last Name.")
    void testUpdateLastName() {
        ContactService service = new ContactService();
        service.addContact("2", "Dr.", "Cross", "5555551111", "123 Lollypop Lane");
        String contactID = service.getContact("2").getContactID();
        service.updateLastName("Shirley", contactID);
        assertEquals("Shirley", service.getContact(contactID).getLastName(), "Last name was not updated.");
    }

    @Test
    @DisplayName("Test to update phone number.")
    void testUpdatePhoneNumber() {
        ContactService service = new ContactService();
        service.addContact("3", "Dr.", "Cross", "5555551111", "123 Lollypop Lane");
        String contactID = service.getContact("3").getContactID();
        service.updatePhone("5555550000", contactID);
        assertEquals("5555550000", service.getContact(contactID).getPhone(), "Phone number was not updated.");
    }

    @Test
    @DisplayName("Test to update address.")
    void testUpdateAddress() {
        ContactService service = new ContactService();
        service.addContact("4", "Dr.", "Cross", "5555551111", "123 Lollypop Lane");
        String contactID = service.getContact("4").getContactID();
        service.updateAddress("555 Nowhere Ave", contactID);
        assertEquals("555 Nowhere Ave", service.getContact(contactID).getAddress(), "Address was not updated.");
    }

    @Test
    @DisplayName("Test to ensure that service correctly deletes contacts.")
    void testDeleteContact() {
        ContactService service = new ContactService();
        service.addContact("5", "Dr.", "Cross", "5555551111", "123 Lollypop Lane");
        String contactID = service.getContact("5").getContactID();
        service.deleteContact(contactID);
        assertNull(service.getContact(contactID), "The contact was not deleted.");
    }

    @Test
    @DisplayName("Test to ensure that service can add a contact.")
    void testAddContact() {
        ContactService service = new ContactService();
        service.addContact("6", "Dr.", "Cross", "5555551111", "123 Lollypop Lane");
        String contactID = service.getContact("6").getContactID();
        assertNotNull(service.getContact(contactID), "Contact was not added correctly.");
    }
}
